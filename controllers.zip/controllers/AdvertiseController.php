<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/5
 * Time: 17:22
 */

namespace app\controllers;


use app\common\behavior\NoCsrs;
use app\models\Ad;
use app\models\Adpos;
use yii\web\Controller;
use Yii;

class AdvertiseController extends Controller
{


    public function behaviors()
    {
        return [
            'csrf' => [
                'class' => NoCsrs::className(),
                'controller' => $this,
                'actions' => [
                    'uppic',
                    "add",
                    "edit",
                    "editsave",
                    'list'

                ]
            ]
        ];
    }

    public function actionList()
    {
        Yii::$app->response->format = 'json';
        $where = [];
        $curPage = 1;
        if (Yii::$app->request->isPost) {
            $search = Yii::$app->request->post();
            foreach ($search as $k => $v) {
                if ($k == 'curpage') {
                    $curPage = $v;
                    continue;
                }
                if ($search[$k]) {
                    $where[] = 'ad.'.$k . ' like "%' . trim($v) . '%"';
                }
            }
        }
        $where = $where ? implode(' and ', $where) : [];
        $pageSize = Yii::$app->params['pagesize'];
        $query = new \yii\db\Query();
        $curPage = $curPage ? $curPage : 1;
        $offset = $pageSize * ($curPage - 1);
        $query = new \yii\db\Query();
        $query = $query->select('ad.*,b.title as pos')
            ->from('ad')
            ->leftJoin('ad_postion as b', 'ad.pos_id=b.id');
        if ($where) {
            $query = $query->where($where);
        }
        $count = $query->count();
        $rs = $query->offset($offset)->limit($pageSize)->orderBy('ad.updated_at desc')->all();
        foreach ($rs as $k => $v) {
            $rs[$k]['updated_at'] = date("Y-m-d H:i:s", $v['updated_at']);
        }
        return ['rs' => $rs, 'totalPage' => $count, 'pageSize' => $pageSize, 'search' => @$search, 'currpage' => $curPage,'auth'=>[]];
    }

    public function actionAdd(){
        Yii::$app->response->format = 'json';
        if(Yii::$app->request->isGet){
            $location =Adpos::find()->asArray()->where('id>=1')->all();
            return ['location'=>$location];
        }
        if(Yii::$app->request->isPost){
           $post = Yii::$app->request->post();
           $adModel = new Ad();
           if(!$adModel->load($post,'ad',false)){
               return ['rs'=>'false','msg'=>'数据错误'];
           }
           $adModel->admin_id = Yii::$app->session->get('admin_id');
           $adModel->created_at = time();
           $adModel->updated_at = time();
           if($adModel->save(false)){
               return ['rs'=>'true'];
           }
            return ['rs'=>'false','msg'=>'数据错误'];

        }
    }
    /*编辑*/
    public function actionEdit(){
        Yii::$app->response->format = 'json';
        $adId = Yii::$app->request->get('id');
        $rs = Ad::find()->asArray()->where('id=' . $adId)->one();
        $location =Adpos::find()->asArray()->where('id>=1')->all();
        return ['ad'=>$rs,'location'=>$location];
    }
    /*编辑保存*/
    public function actionEditsave(){
        Yii::$app->response->format = 'json';
        $post = Yii::$app->request->post();
        $adModel = Ad::findOne($post['ad']['id']);
        unset($post['ad']['updated_at']);
        $adModel->updated_at=time();

        if($adModel->load($post,'ad',false)&&$adModel->save(false)){
           // return $adModel;
            return ['rs'=>'true'];
        }
        return ['rs'=>'false','msg'=>'更新失败'];
    }

}
