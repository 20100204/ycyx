<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/21
 * Time: 17:08
 */

namespace app\controllers;


use app\common\behavior\NoCsrs;
use app\models\Admin;
use app\models\Coupon;
use app\models\Couponsendlog;
use app\models\Ycypuser;
use app\queue\CouponJob;
use yii\db\Exception;
use yii\web\Controller;
use Yii;
class CouponController extends Controller
{

    public function behaviors()
    {
        return [
            'csrf' => [
                'class' => NoCsrs::className(),
                'controller' => $this,
                'actions' => [
                    'typechange',
                    'add',
                    'check',
                    'edit',
                    "send"
                ]
            ]
        ];
    }

    /* 送券*/
    public function actionSend(){
        Yii::$app->response->format = 'json';
         $post = Yii::$app->request->post();
         if(!$post['scope']||!$post['couponId']){
             return ['rs'=>'false','msg'=>'参数缺失'.__LINE__];
         }
        $adminId = Yii::$app->session->get("admin_id");
        if($post['scope']=="个人"||$post['scope']=="市公司"||!$adminId){
             if(!$post['select']){
                 return ['rs'=>'false','msg'=>'参数缺失'.__LINE__];
             }
         }
        $db = Yii::$app->db;
        $transcation = $db->beginTransaction();
        try{
            $time = time();
            $msg = $post['scope'].'|'.$post['couponId'].'|'.$post['select'];
            $logModel = new Couponsendlog();
            $logModel->admin_id = $adminId;
            $logModel->coupon_id = $post['couponId'];
            $logModel->created_at = $time;
            $logModel->detail = $msg;
            $logModel->status = 3; //表示状态待定;
            if(!$logModel->save(false)){
                throw new Exception("发送失败");
            }
            $coupon = Coupon::findOne($post['couponId']);
            Yii::$app->queue->push(new CouponJob([
                'range'=>$post['scope'],
                'couponId'=>$post['couponId'],
                'expired'=>$coupon->expired,
                'title'=>$coupon->title,
                'select'=>$post['select']
            ]));

            $transcation->commit();
        }catch (Exception $e){
            $transcation->rollBack();
            return ['rs'=>'false','msg'=>$e->getMessage()];
        }





         return ["rs"=>"true"];

    }

    /*送券首页*/
    public function actionIndex(){
        Yii::$app->response->format = 'json';
        //获取城市列表
        $city = [];
        $isCity = false;
        if (Yii::$app->session->get('parent_admin_role_id') == '2') {
            $isCity = true;
            $city = [Yii::$app->session->get('role_area')];
        }else{
            $city = Admin::find()->select('admin.area,admin.city')->leftJoin('admin_role', 'admin.admin_role_id=admin_role.id')->groupBy('admin.city')->where('admin.status=1 and admin_role.parent_id=2 and admin.admin_role_id=10')->asArray()->all();

        }
        return ['isCity'=>$isCity,'city'=>$city];
    }

    /*优惠券类别发生变化时*/
    public function actionTypechange(){
        Yii::$app->response->format = 'json';
        $post = Yii::$app->request->post();

        if(!$post['scope']||!$post['type']){
            return ["rs"=>"false","msg"=>"参数缺失".__LINE__];
        }
        if($post['scope']=="市公司"||$post['scope']=="个人"){
            if(!$post['select']){
                return ["rs"=>"false","msg"=>"参数缺失".__LINE__];
            }
        }
     return   $rs = $this->usecoupon($post['scope'],$post['type'],$post['select']);

    }

    /*根据条件返回可用券列表*/
    private function usecoupon($range,$type,$select){

        $rs = [];
        $type = $type==1?"cash":"discount";
        switch ($range){
            case "全国":
                $rs = Coupon::find()->where("scope=0 and status=1 and coupon_type='".$type."'")->select("id,title")->asArray()->all();
                break;
            case "市公司":
               $rs = Coupon::find()->where("(scope=0 and status=1 and coupon_type='".$type."') or(scope=1 and status=1 and coupon_type='".$type."' and scope_info like '%".$select."%' )")->select("id,title")->asArray()->all();
                break;
            case "个人":
               $userModel =  Ycypuser::find()->where("mobile=".$select)->asArray()->one();
               $area = explode(":",$userModel['area']);
               $area = $area[0].':'.$area[1];
               $rs = Coupon::find()->where("(scope=0 and status=1 and coupon_type='".$type."') or(scope=1 and status=1 and coupon_type='".$type."' and scope_info like '%".$area."%' )")->select("id,title")->asArray()->all();
               break;
        }

        return $rs;
    }
}


